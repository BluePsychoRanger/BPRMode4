## Sky Void Worldgen (Single Lava)
The `skyvoid_worldgen_single_lava` data pack generates an infinite void world with properties akin to the original SkyBlock. Every end portal will have a single block of lava beneath it. For more information, visit the [wiki](https://github.com/BPR02/SkyBlock_Collection/wiki).
